double find_median(double *measurements, uint32_t num_measurements);
