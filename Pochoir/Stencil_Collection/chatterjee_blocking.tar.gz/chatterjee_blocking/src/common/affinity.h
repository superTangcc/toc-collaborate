void Affinity_Init(void);
void Affinity_Bind_Memory(uint32_t thread);
void Affinity_Bind_Thread(uint32_t thread);
void Affinity_unBind(void);
