void Affinity_Init(){ 
  printf("not implementing NUMA\n");
  return;
}

void Affinity_Bind_Memory(uint32_t thread){
  return;
}

void Affinity_Bind_Thread(uint32_t thread){
  return;
}

void Affinity_unBind(){
  return;
}
