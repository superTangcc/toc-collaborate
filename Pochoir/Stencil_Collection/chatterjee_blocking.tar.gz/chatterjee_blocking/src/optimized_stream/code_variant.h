uint32_t read_arrays_case, write_arrays_case, write_type_case, load_type_case, loop_unroll_case, prefetch_distance_case;

void select_code_variant(char *argv[]);
void print_code_variant_parameters(void);
