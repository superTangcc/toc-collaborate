void *pthreads_each(void *rank_ptr);
