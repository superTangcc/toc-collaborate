uint32_t prefetch_index_type, prefetch_distance, rb_size;

void select_code_variant(char *argv[]);
void print_code_variant_parameters(void);
