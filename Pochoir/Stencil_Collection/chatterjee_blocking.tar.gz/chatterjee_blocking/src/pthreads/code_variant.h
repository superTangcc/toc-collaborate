int32_t statement_type, read_from_type, pointer_type, neighbor_index_type, fma_ins_type, prefetch_index_type, prefetch_distance, rb_size;

void select_code_variant(char *argv[]);
void print_code_variant_parameters(void);
