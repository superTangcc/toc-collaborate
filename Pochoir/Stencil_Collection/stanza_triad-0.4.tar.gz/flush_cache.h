void init_flush_cache_array();
void flush_cache();
double flush_cache_checksum();
