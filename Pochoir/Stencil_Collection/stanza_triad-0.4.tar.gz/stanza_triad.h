double find_median(double *measurements, int num_measurements);
void init_read_arrays();
void init_write_array();
double stanza_triad_checksum();
void stanza_triad(uint64_t stanza_length);
